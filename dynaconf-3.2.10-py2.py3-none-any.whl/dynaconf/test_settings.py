# pragma: no cover
from __future__ import annotations

TESTING = True
LOADERS_FOR_DYNACONF = [
    "dynaconf.loaders.env_loader",
    # 'dynaconf.loaders.redis_loader'
]
